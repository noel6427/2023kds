#ifndef CAN_H
#define CAN_H

#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Int8.h"

#include <linux/can.h>
#include <linux/can/raw.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <iostream>
#include <string.h>
#include <fcntl.h>

#define PI 3.14159265

/***************RPM*************/
#define DPS2RPM       0.166666
#define RPM2DSP       6.0000024
/*******************************/
#define ANSI_COLOR_RED      "\x1b[31m"
#define ANSI_COLOR_GREEN    "\x1b[32m"
#define ANSI_COLOR_YELLOW   "\x1b[33m"
#define ANSI_COLOR_BLUE     "\x1b[34m"
#define ANSI_COLOR_MAGENTA  "\x1b[35m"
#define ANSI_COLOR_CYAN     "\x1b[36m"
#define ANSI_COLOR_RESET    "\x1b[0m"

/***************ENO************/
#define DEG2LSP       100
#define ENCODER_RANGE 32767      // 16bit encoder // +-32767 // 0~65535 // 16383
#define DEG2ENC       91.0194   // 65536 / 360(deg)=182.0444 // 16383/360=45.50833
#define ENC2DEG       0.010987  // 360/32767=0.010987 // 360 / 65536=0.005493   // 360/16383=0.002197
#define DEG2RAD       0.017453   // PI / 180
#define RAD2DEG       57.29578   // 180 / PI
/*******************************/


/**************************Motor Command**********************/
#define SPEED_CLOESED_LOOP_CMMD                               0XA2

#define POSITION_CLOSED_LOOP_CMMD                             0xA4
#define MOTOR_STOP_CMMD                                       0X81


/**************************************************************/


using namespace std;

typedef unsigned char  BYTE;  //8bit
typedef unsigned short BYTE2; //16bit
typedef unsigned int BYTE4;   //32bit


enum Bit_rate {
  _10k = 0,
  _20k,
  _50k,
  _100k,
  _125k,
  _250k,
  _500k,
  _750k,
  _1M
};
struct MOTOR{
  int Encoder_Data;
  int Ver;
  double start_posi;
  double goal_posi;
  double goal_posi_1 = 0.0  *DEG2RAD;
  double goal_posi_2 = 360.0 *DEG2RAD;
  double present_posi = 0;  //radian
  double command_posi = 0;
};
typedef MOTOR M;


class CAN
{
  private:
    int soc;
    int read_can_port;
    string port_name;        //socket CAN port name. such as "can0"
    string device_name;  //Port of USB_to_CAN device port such as "ttyACM0". Can find it in "/dev" directory.

  public :
    CAN(string port_name_, string device_name_);
    ~CAN();

    M mot1;
    M mot2;
    M mot3;

    int flag_1 =0;
    int flag_2 =0;
    double start_1 =0;
    double start_2 =0;

    int open_port(const char *port);
    int send_port(struct can_frame *frame);
    int close_port();
    int Read_Present_Pos();

    void baud_n_openport(int bit_rate_mode);
    void set_can_frame(struct can_frame &canframe, int CAN_id, u_int8_t CAN_data_len, bool is_ext_mode);
    bool read_CAN(struct can_frame &recv_frame);
    void CAN_write(struct can_frame &frame, BYTE data_array[]);
    void SoftwareVer(int RMD_id);
    void update();
    void run_at_sametime(int32_t Pos_Deg);
    void joint_RPM_Ctrl_1(int32_t rpm, int32_t RMD_id);
    void Position_GoV3(int RMD_id, double position_degree);
    void Position_Init_V3(int RMD_id);
    void Read_RMD_Data();
    void Set_ZeroPos_1();
    void Motor_Stop(int RMD_id);
};



#endif // CAN_H
