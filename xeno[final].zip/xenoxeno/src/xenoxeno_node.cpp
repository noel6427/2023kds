#include "ros/ros.h"
#include "std_msgs/String.h"
#include "sensor_msgs/Joy.h"
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <math.h>

//======================================CAN=========================================
#include "xenoxeno/cancan.h"
#include "std_msgs/Int32.h"
#include "std_msgs/Float32.h"

//======================================Save=========================================
#include <fstream>
#include <string>

//======================================Xenomai======================================
#include <xenomai/alchemy/task.h>
#include <xenomai/alchemy/timer.h>
#include <xenomai/alchemy/mutex.h>

#define TASK_PRIORITY 99 /*The priority of the task can have a value from 1 to 99. In this case, the priority is set to 99.*/
#define TASK_MODE 0 /*The task mode indicates the mode of the task, usually with values like TASK_MODE_NORMAL, TASK_MODE_RT. In this case, the mode is set to 0, which corresponds to TASK_MODE_NORMAL.*/
#define TASK_STACK_SIZE 0 /*Defining the size of stack memory to be used by a task. It is set to 0 because Xenomai automatically determines the stack size.*/

RT_TASK task_1;
RT_TASK task_2;
RT_TASK task_3;
RT_MUTEX my_mutex;

RTIME task_time[1200][9] = {};
int total_thread = 3;

bool task_run = true;
bool load_run = true;

//======================================CAN===========================================

CAN _can("can0", "ttyACM0");
double T = 300;
double t =0.0;
double dt = 1.0;

int cnt =0;
int max_cnt = 1000;


//======================================function======================================
void save();

void CAN_RMD_RUN(void *arg);
void CAN_RMD_INIT(void *arg);

void load();

using namespace std;

int main(int argc, char **argv)
{
  ros::init(argc, argv, "xenoxeno_node");
  ros::NodeHandle nh;
  ros::Publisher chatter_pub = nh.advertise<std_msgs::Float32>("chatter", 1000);

  _can.baud_n_openport(_1M);

  _can.flag_1 = 0;
  _can.flag_2 = 0;

  _can.start_1 = 0;
  _can.start_2 = 0;

  struct can_frame rx_frame;

  _can.update();

  load();

  usleep(5000000);

  rt_task_create(&task_1, "xeno_task_1", TASK_STACK_SIZE, 99, T_JOINABLE);
  rt_task_set_periodic(&task_1, TM_NOW, 10000000); // 10 ms
  rt_task_start(&task_1, &CAN_RMD_RUN, NULL);

//  rt_task_create(&task_2, "xeno_task_2", TASK_STACK_SIZE, 98, T_JOINABLE);
//  rt_task_set_periodic(&task_2, TM_NOW, 10000000); // 10 ms
//  rt_task_start(&task_2, &CAN_RMD_RUN1, NULL);

  rt_print_init(0,"xeno_task_1");
  rt_print_init(0,"xeno_task_2");
  rt_mutex_create(&my_mutex, NULL);

//  rt_task_join(&task_1);
//  rt_task_join(&task_2);

  while (ros::ok())
    {
      ros::spinOnce();
      std_msgs::Float32 msg;
      chatter_pub.publish(msg);
    }

  rt_task_delete(&task_1);
  rt_mutex_delete(&my_mutex);

  _can.close_port();
  return 0;
}

void load()
{
  for(int i=0;i<10;i++)
  {
    _can.joint_RPM_Ctrl_1(0,0x142);
    _can.joint_RPM_Ctrl_1(0,0x143);
    _can.Read_RMD_Data();
    printf(ANSI_COLOR_GREEN"Encoder_Data_mot1: %d |"\
           ANSI_COLOR_YELLOW" Encoder_Data_mot2 :%d |"\
           ANSI_COLOR_CYAN" Encoder_Data_mot3 :%d"\
           ANSI_COLOR_RESET"\n",_can.mot1.Encoder_Data,_can.mot2.Encoder_Data,_can.mot3.Encoder_Data);

    usleep(2000);
  }
 usleep(3000000);

  rt_task_create(&task_3, "xeno_task_3", TASK_STACK_SIZE, TASK_PRIORITY, TASK_MODE);
  rt_task_start(&task_3, &CAN_RMD_INIT, NULL);

}
void save()
{
    ofstream file;
    file.open("/home/nuc2/catkin_ws/test_save/time.txt",ios_base::app);
     for(int i=2;i<=max_cnt;i++)
        {
            ROS_INFO("Saving_%d",i);
            file <<(task_time[i][0] - task_time[i-1][0])/1000000.0<<", "\
                 <<(task_time[i][1] - task_time[i][0])/1000000.0<<", "\
                 <<(task_time[i][2] - task_time[i][1])/1000000.0<<", "\
                 <<(task_time[i][3] - task_time[i][2])/1000000.0<<", "\
                 <<(task_time[i][5] - task_time[i-1][5])/1000000.0<<", "\
                 <<(task_time[i][6] - task_time[i][5])/1000000.0<<", "\
                 <<(task_time[i][7] - task_time[i][6])/1000000.0<<"\n";
        }
        cout<<"==============================save success=============================="<<endl;

    file.close();
}

void CAN_RMD_RUN(void *arg){
  printf("task1 is start\n");
 _can.Read_RMD_Data();
 _can.Read_RMD_Data();
 _can.Read_RMD_Data();
 _can.mot1.start_posi = _can.mot1.Encoder_Data*ENC2DEG*DEG2RAD;
 _can.mot1.goal_posi = 180.0 *DEG2RAD;

 _can.mot2.start_posi = _can.mot2.Encoder_Data*ENC2DEG*DEG2RAD;
 _can.mot2.goal_posi = 360.0 *DEG2RAD;

 _can.mot3.start_posi = _can.mot3.Encoder_Data*ENC2DEG*DEG2RAD;
 _can.mot3.goal_posi = 270.0 *DEG2RAD;

  while (task_run)
  {

    _can.mot1.command_posi = _can.mot1.start_posi+(_can.mot1.goal_posi - _can.mot1.start_posi)*0.5*(1.0-cos(PI*(t/T)));
    _can.mot2.command_posi = _can.mot2.start_posi+(_can.mot2.goal_posi - _can.mot2.start_posi)*0.5*(1.0-cos(PI*(t/T)));
    _can.mot3.command_posi = _can.mot3.start_posi+(_can.mot3.goal_posi - _can.mot3.start_posi)*0.5*(1.0-cos(PI*(t/T)));



    _can.Position_GoV3(0x141,_can.mot1.command_posi*RAD2DEG);

    _can.Position_GoV3(0x142,_can.mot2.command_posi*RAD2DEG);

    _can.Position_GoV3(0x143,_can.mot3.command_posi*RAD2DEG);

      t +=dt;

//    if (cnt==max_cnt)
//    {
//     task_run = false;
//     save();
//     printf("==============================END================================\n");
//      return;
//    }

// rt_mutex_release(&my_mutex);

 rt_task_wait_period(NULL);
  }
}

void CAN_RMD_INIT(void *arg){
    printf("task3 is start\n");
    rt_task_set_periodic(NULL, TM_NOW, 10000000);

    while (load_run)
    {
      rt_mutex_acquire(&my_mutex, TM_INFINITE);

      _can.mot1.goal_posi = 0;
      _can.mot1.present_posi = _can.mot1.Encoder_Data*ENC2DEG*DEG2RAD;
      _can.mot1.start_posi = _can.mot1.present_posi;
      _can.mot1.command_posi = _can.mot1.start_posi+(_can.mot1.goal_posi - _can.mot1.start_posi)*0.5*(1.0-cos(PI*(t/500)));

      _can.mot2.goal_posi = 0;
      _can.mot2.present_posi = _can.mot2.Encoder_Data*ENC2DEG*DEG2RAD;
      _can.mot2.start_posi = _can.mot2.present_posi;
      _can.mot2.command_posi = _can.mot2.start_posi+(_can.mot2.goal_posi - _can.mot2.start_posi)*0.5*(1.0-cos(PI*(t/500)));

      _can.mot3.goal_posi = 0;
      _can.mot3.present_posi = _can.mot2.Encoder_Data*ENC2DEG*DEG2RAD;
      _can.mot3.start_posi = _can.mot2.present_posi;
      _can.mot3.command_posi = _can.mot2.start_posi+(_can.mot2.goal_posi - _can.mot2.start_posi)*0.5*(1.0-cos(PI*(t/500)));

      _can.Position_GoV3(0x141,_can.mot1.command_posi*RAD2DEG);

      _can.Position_GoV3(0x142,_can.mot2.command_posi*RAD2DEG);

      _can.Position_GoV3(0x143,_can.mot3.command_posi*RAD2DEG);

      t ++;

    if (t >=500)
    {
      load_run = false;
      t = 0.0;
    }

    rt_mutex_release(&my_mutex);
    rt_task_wait_period(NULL);

    }
    printf(ANSI_COLOR_MAGENTA"=============================INIT COMPLETE==========================="ANSI_COLOR_RESET"\n");
    rt_task_delete(&task_3);
}
